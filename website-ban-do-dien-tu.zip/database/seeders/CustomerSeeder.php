<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Customer;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\Hash;

class CustomerSeeder extends Seeder
{
    public function run()
    {
        $faker = Faker::create();

        for ($i = 0; $i < 20; $i++) {
            Customer::create([
                'username' => $faker->unique()->userName,
                'password' => Hash::make('password'),
                'fullname' => $faker->name,
                'gender' => $faker->numberBetween(0, 1),
                'email' => $faker->unique()->email,
                'phone' => $faker->numerify('0#########'),
                'address' => $faker->address,
                'avatar' => $faker->imageUrl(),
                'status' => $faker->numberBetween(0, 1),
            ]);
        }
    }
}
