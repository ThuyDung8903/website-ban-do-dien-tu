<div class="d-inline">
    <?php echo e($wishlistCount); ?>

</div>
<?php /**PATH D:\Workspace\Laravel\website-ban-do-dien-tu\resources\views/livewire/frontend/wishlist-count.blade.php ENDPATH**/ ?>