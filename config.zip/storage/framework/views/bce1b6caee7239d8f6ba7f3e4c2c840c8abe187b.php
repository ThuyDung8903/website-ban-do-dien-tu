

<?php $__env->startSection('title', 'Search Results'); ?>

<?php $__env->startSection('content'); ?>

    <div class="py-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <h4>Search results for <strong>"<?php echo e($keyword); ?>"</strong></h4>
                    <hr/>
                </div>

                <?php $__empty_1 = true; $__currentLoopData = $searchProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-10">
                        <div class="product-card">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="product-card-img">
                                        <?php if($productItem->quantity > 0): ?>
                                            <label class="stock bg-success">In Stock</label>
                                        <?php else: ?>
                                            <label class="stock bg-danger">Out of Stock</label>
                                        <?php endif; ?>
                                        <?php if($productItem->images->count() > 0): ?>
                                            <a href="<?php echo e(url('/collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                                <img src="<?php echo e($productItem->images[0]->path); ?>"
                                                     alt="<?php echo e($productItem->name); ?>">
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <div class="product-card-body">
                                        <p class="product-brand"><?php echo e($productItem->brands->name); ?></p>
                                        <h5 class="product-name">
                                            <a href="<?php echo e(url('/collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>">
                                                <?php echo e($productItem->name); ?>

                                            </a>
                                        </h5>
                                        <div>
                                            <span class="selling-price">$<?php echo e($productItem->sale_price); ?></span>
                                            <span class="original-price">$<?php echo e($productItem->price); ?></span>
                                        </div>
                                        <p style="height: 45px; overflow: hidden">
                                            <b>Description: </b><?php echo e($productItem->short_description); ?>

                                        </p>
                                        <a href="<?php echo e(url('/collections/'.$productItem->category->slug.'/'.$productItem->slug)); ?>"
                                           class="btn btn-sm btn-warning px-3">
                                            View details
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12 p-2">
                        <div class="p-2">
                            <h4>No search result</h4>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-md-10">
                    <?php echo e($searchProducts->appends(request()->input())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\website-ban-do-dien-tu\resources\views/frontend/pages/search.blade.php ENDPATH**/ ?>