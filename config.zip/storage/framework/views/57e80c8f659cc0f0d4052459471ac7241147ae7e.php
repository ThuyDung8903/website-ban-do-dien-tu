<div class="d-inline">
    <?php echo e($cartCount); ?>

</div>
<?php /**PATH D:\Workspace\Laravel\website-ban-do-dien-tu\resources\views/livewire/frontend/cart/cart-count.blade.php ENDPATH**/ ?>