

<?php $__env->startSection('title'); ?>
    <?php echo e($category->meta_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_keywords'); ?>
    <?php echo e($category->meta_keywords); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_description'); ?>
    <?php echo e($category->meta_description); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="py-3 py-md-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="mb-4">List Products in <?php echo e($category->name); ?></h4>
                </div>

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.product.index', ['category' => $category])->html();
} elseif ($_instance->childHasBeenRendered('gHIqB47')) {
    $componentId = $_instance->getRenderedChildComponentId('gHIqB47');
    $componentTag = $_instance->getRenderedChildComponentTagName('gHIqB47');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gHIqB47');
} else {
    $response = \Livewire\Livewire::mount('frontend.product.index', ['category' => $category]);
    $html = $response->html();
    $_instance->logRenderedChild('gHIqB47', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\website-ban-do-dien-tu\resources\views/frontend/collections/products/index.blade.php ENDPATH**/ ?>