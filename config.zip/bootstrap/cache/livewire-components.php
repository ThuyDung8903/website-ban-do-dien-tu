<?php return array (
  'frontend.cart.cart-count' => 'App\\Http\\Livewire\\Frontend\\Cart\\CartCount',
  'frontend.cart.cart-show' => 'App\\Http\\Livewire\\Frontend\\Cart\\CartShow',
  'frontend.checkout.checkout-show' => 'App\\Http\\Livewire\\Frontend\\Checkout\\CheckoutShow',
  'frontend.product.index' => 'App\\Http\\Livewire\\Frontend\\Product\\Index',
  'frontend.product.view' => 'App\\Http\\Livewire\\Frontend\\Product\\View',
  'frontend.wishlist-count' => 'App\\Http\\Livewire\\Frontend\\WishlistCount',
  'frontend.wishlist-show' => 'App\\Http\\Livewire\\Frontend\\WishlistShow',
);