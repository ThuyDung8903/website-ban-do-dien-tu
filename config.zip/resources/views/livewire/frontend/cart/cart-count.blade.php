<div class="d-inline">
    {{ $cartCount }}
</div>
