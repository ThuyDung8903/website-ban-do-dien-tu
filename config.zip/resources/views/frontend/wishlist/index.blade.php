@extends('layouts.app')

@section('title', 'Wislist Page')

@section('content')
    <livewire:frontend.wishlist-show />
@endsection
